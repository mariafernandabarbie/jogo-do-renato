window.onload = () => {
    "use strict";
    if("serviceWorker" in navigator){
        navigator.serviceWorker.register("./sw.js");
    }
};

document.addEventListener("DOMContentLoaded", () => {
    const board = document.getElementById('board');
    const cells = document.querySelectorAll('[data-cell]');
    const message = document.getElementById('message');
    const resetButton = document.getElementById('resetButton');
    let currentPlayer = 'X';
    let boardState = ['', '', '', '', '', '', '', '', ''];
    let gameWon = false;
  
    function checkWinner() {
      const winPatterns = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],  // Linhas
        [0, 3, 6], [1, 4, 7], [2, 5, 8],  // Colunas
        [0, 4, 8], [2, 4, 6]              // Diagonais
      ];
  
      for (const pattern of winPatterns) {
        const [a, b, c] = pattern;
        if (boardState[a] && boardState[a] === boardState[b] && boardState[a] === boardState[c]) {
          gameWon = true;
          return boardState[a];
        }
      }
  
      if (boardState.every(cell => cell !== '')) {
        gameWon = true;
        return 'Empate';
      }
  
      return null;
    }
  
    function handleClick(index) {
      if (gameWon || boardState[index] !== '') return;
  
      boardState[index] = currentPlayer;
      cells[index].textContent = currentPlayer;
  
      const winner = checkWinner();
      if (winner) {
        if (winner === 'Empate') {
          message.textContent = 'Empate! O jogo acabou.';
        } else {
          message.textContent = `Jogador ${winner} ganhou!`;
        }
        gameWon = true;
      } else {
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        message.textContent = `É a vez do jogador ${currentPlayer}`;
      }
    }
  
    function resetGame() {
      boardState = ['', '', '', '', '', '', '', '', ''];
      gameWon = false;
      currentPlayer = 'X';
      message.textContent = `É a vez do jogador ${currentPlayer}`;
      cells.forEach(cell => cell.textContent = '');
    }
  
    cells.forEach((cell, index) => {
      cell.addEventListener('click', () => {
        if (!gameWon) {
          handleClick(index);
        }
      });
    });
  
    resetButton.addEventListener('click', resetGame);
  
    resetGame();
  });
  

